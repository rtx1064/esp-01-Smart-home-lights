// #ifndef BlinkerDataTicker_H
// #define BlinkerDataTicker_H

// #if defined(ESP8266) || defined(ESP32)

// #include "Blinker/BlinkerConfig.h"
// #include "Blinker/BlinkerDebug.h"
// #include "Blinker/BlinkerTimer.h"

// #include <Ticker.h>

// Ticker dataTicker;

// bool _dataTrigged = false;
// uint32_t _data_time = 60;

// void dataInit(uint8_t mins, uint8_t seconds, uint32_t tickers = 60)
// {
//     _data_time = tickers;

//     if (_data_time == 60)
//     {
//         uint32_t tTime = _data_time - seconds;
//         dataTicker.
//     }
// }

// void dataHandle()
// {
//     _dataTrigged = true;
// }

// #endif

// #endif
